# Puremoto IRL

Example codebase for IRL integration

### Requirements

- >= npm v6
- >= node v10

### Getting started

- `npm i` from project root.
- Start server `npm start`
- Open browser and navigate to `http://localhost:3001`